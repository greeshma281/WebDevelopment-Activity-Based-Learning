# Web Development Activity-Based Learning Project

This project implements **three case studies** from the supplied university task list:
1. Personal Portfolio Website
2. College Information and Admissions Website
3. Online Learning Platform Interface

## Technologies
- HTML5 semantic elements
- CSS3 responsive layouts, Grid, Flexbox, transitions and animations
- Vanilla JavaScript for mobile navigation, course filtering, progress interaction and form validation

## Run locally
1. Extract the ZIP file.
2. Open `portfolio/index.html`, `college/index.html`, or `learning/index.html` in a modern browser.
3. No package installation or internet connection is required for the core layout and interactions.

## Project contents
- `portfolio/` — profile, education, skills, projects, achievements and contact form
- `college/` — college overview, departments, courses, facilities, admissions steps and enquiry form
- `learning/` — course categories, instructor cards, course descriptions, search/filter and progress indicators
- `documentation/` — problem statements, objectives, algorithms, test plans and student details template
- `assets/` — local SVG illustrations

## Before submission
Fill out `documentation/student_details.txt`. Test the pages on desktop and mobile widths, and capture genuine screenshots from your browser if required by your faculty. The forms are front-end demonstrations and do not send data to a server. Replace sample profile details with your own accurate information.

**Academic note:** The task sheet says to select any 3 case studies. These are the first three listed case studies, implemented as separate responsive pages.
