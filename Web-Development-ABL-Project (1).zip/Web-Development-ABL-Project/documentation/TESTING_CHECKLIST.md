# Testing Checklist

- [ ] Open all three `index.html` pages in a current browser.
- [ ] Click each navigation link and verify it moves to the correct section.
- [ ] Test at desktop width and narrow/mobile width.
- [ ] Verify navigation menu toggles on narrow screens.
- [ ] Submit forms with missing values; browser validation should prevent submission.
- [ ] Submit valid form values; a local demo message should appear.
- [ ] On the learning page, search for a course and use category filters.
- [ ] On the learning page, click progress buttons and confirm bars update.
- [ ] Confirm no console errors during normal interactions.

Forms are demonstration-only and do not send or store personal data.
